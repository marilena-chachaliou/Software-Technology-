package inncontrol;

public class Room {
    private String number;
    private String type;
    private String status;

    public Room(String number, String type, String status) {
        this.number = number;
        this.type = type;
        this.status = status;
    }

    public String getNumber() { return number; }
    public String getType() { return type; }
    public String getStatus() { return status; }
}

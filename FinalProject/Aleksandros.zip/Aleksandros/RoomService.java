package inncontrol;

public class RoomService {
    private int id;
    private String roomNumber;
    private String request;
    private String status;
    private String timestamp;

    public RoomService(int id, String roomNumber, String request, String status, String timestamp) {
        this.id = id;
        this.roomNumber = roomNumber;
        this.request = request;
        this.status = status;
        this.timestamp = timestamp;
    }

    public int getId() { return id; }
    public String getRoomNumber() { return roomNumber; }
    public String getRequest() { return request; }
    public String getStatus() { return status; }
    public String getTimestamp() { return timestamp; }
}
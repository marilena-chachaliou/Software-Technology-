package inncontrol;

public class StaffLeave {
    private int id;
    private int staffId;
    private String leaveStart;
    private String leaveEnd;
    private String reason;

    public StaffLeave(int id, int staffId, String leaveStart, String leaveEnd, String reason) {
        this.id = id;
        this.staffId = staffId;
        this.leaveStart = leaveStart;
        this.leaveEnd = leaveEnd;
        this.reason = reason;
    }

    public int getId() { return id; }
    public int getStaffId() { return staffId; }
    public String getLeaveStart() { return leaveStart; }
    public String getLeaveEnd() { return leaveEnd; }
    public String getReason() { return reason; }
}
package inncontrol;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.sql.*;

public class StaffLeaveController {

    @FXML private TableView<StaffLeave> leaveTable;
    @FXML private TableColumn<StaffLeave, Integer> colId;
    @FXML private TableColumn<StaffLeave, Integer> colStaffId;
    @FXML private TableColumn<StaffLeave, String> colFrom;
    @FXML private TableColumn<StaffLeave, String> colTo;
    @FXML private TableColumn<StaffLeave, String> colReason;

    private ObservableList<StaffLeave> leaves = FXCollections.observableArrayList();

    // Database connection info
    private final String DB_URL = "jdbc:mysql://localhost:3306/inncontrol";
    private final String DB_USER = "root";
    private final String DB_PASS = "";

    @FXML
    public void initialize() {
        colId.setCellValueFactory(new PropertyValueFactory<>("id"));
        colStaffId.setCellValueFactory(new PropertyValueFactory<>("staffId"));
        colFrom.setCellValueFactory(new PropertyValueFactory<>("leaveStart"));
        colTo.setCellValueFactory(new PropertyValueFactory<>("leaveEnd"));
        colReason.setCellValueFactory(new PropertyValueFactory<>("reason"));

        leaveTable.setItems(leaves);

        loadData();
    }

    private Connection connect() throws SQLException {
        return DriverManager.getConnection(DB_URL, DB_USER, DB_PASS);
    }

    private void loadData() {
        leaves.clear();
        try (Connection conn = connect()) {
            String query = "SELECT * FROM staff_leaves ORDER BY leave_start DESC";
            PreparedStatement stmt = conn.prepareStatement(query);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                leaves.add(new StaffLeave(
                    rs.getInt("id"),
                    rs.getInt("staff_id"),
                    rs.getString("leave_start"),
                    rs.getString("leave_end"),
                    rs.getString("reason")
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert("Error loading leave data.");
        }
    }

    public void handleRequest() {
        showAlert("Request Leave clicked. Implement this as needed.");
    }

    public void handleApprove() {
        StaffLeave selected = leaveTable.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showAlert("Please select a leave request to approve.");
            return;
        }
        showAlert("Approve Leave clicked for staff ID " + selected.getStaffId());
    }

    public void handleReject() {
        StaffLeave selected = leaveTable.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showAlert("Please select a leave request to reject.");
            return;
        }
        showAlert("Reject Leave clicked for staff ID " + selected.getStaffId());
    }

    private void showAlert(String msg) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Staff Leave");
        alert.setHeaderText(null);
        alert.setContentText(msg);
        alert.showAndWait();
    }
}
package inncontrol;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.sql.*;

public class RoomsController {

    @FXML private TableView<Room> roomTable;
    @FXML private TableColumn<Room, String> colNumber;
    @FXML private TableColumn<Room, String> colType;
    @FXML private TableColumn<Room, String> colStatus;

    @FXML private TextField roomNumberField;
    @FXML private ComboBox<String> roomTypeCombo;
    @FXML private CheckBox availableCheckBox;

    private ObservableList<Room> rooms = FXCollections.observableArrayList();

    private final String DB_URL = "jdbc:mysql://localhost:3306/inncontrol";
    private final String DB_USER = "root";
    private final String DB_PASS = "";

    @FXML
    public void initialize() {
        colNumber.setCellValueFactory(new PropertyValueFactory<>("number"));
        colType.setCellValueFactory(new PropertyValueFactory<>("type"));
        colStatus.setCellValueFactory(new PropertyValueFactory<>("status"));

        roomTable.setItems(rooms);
        loadRoomTypes();
        loadRoomsFromDB();
    }

    private void loadRoomsFromDB() {
        rooms.clear();
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS)) {
            String sql = "SELECT r.room_number, t.name AS type, r.is_available " +
                         "FROM rooms r LEFT JOIN room_types t ON r.type_id = t.id";
            PreparedStatement stmt = conn.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                String number = rs.getString("room_number");
                String type = rs.getString("type");
                boolean isAvailable = rs.getBoolean("is_available");
                String status = isAvailable ? "Available" : "Occupied";
                rooms.add(new Room(number, type, status));
            }

        } catch (SQLException e) {
            showAlert("Error loading rooms: " + e.getMessage());
        }
    }

    private void loadRoomTypes() {
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS)) {
            String sql = "SELECT name FROM room_types";
            PreparedStatement stmt = conn.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                roomTypeCombo.getItems().add(rs.getString("name"));
            }
        } catch (SQLException e) {
            showAlert("Error loading room types: " + e.getMessage());
        }
    }

    public void handleAdd() {
        String number = roomNumberField.getText();
        String type = roomTypeCombo.getValue();
        boolean available = availableCheckBox.isSelected();

        if (number.isEmpty() || type == null) {
            showAlert("Please fill in all fields.");
            return;
        }

        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS)) {
            int typeId = getRoomTypeId(conn, type);
            String sql = "INSERT INTO rooms (room_number, type_id, is_available) VALUES (?, ?, ?)";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, number);
            stmt.setInt(2, typeId);
            stmt.setBoolean(3, available);
            stmt.executeUpdate();
            showAlert("Room added!");
            clearForm();
            loadRoomsFromDB();
        } catch (SQLException e) {
            showAlert("Error adding room: " + e.getMessage());
        }
    }

    public void handleEdit() {
        Room selected = roomTable.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showAlert("Select a room to edit.");
            return;
        }

        String newNumber = roomNumberField.getText();
        String newType = roomTypeCombo.getValue();
        boolean available = availableCheckBox.isSelected();

        if (newNumber.isEmpty() || newType == null) {
            showAlert("Please fill in all fields.");
            return;
        }

        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS)) {
            int typeId = getRoomTypeId(conn, newType);
            String sql = "UPDATE rooms SET type_id = ?, is_available = ? WHERE room_number = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, typeId);
            stmt.setBoolean(2, available);
            stmt.setString(3, selected.getNumber());
            stmt.executeUpdate();
            showAlert("Room updated!");
            clearForm();
            loadRoomsFromDB();
        } catch (SQLException e) {
            showAlert("Error editing room: " + e.getMessage());
        }
    }

    public void handleDelete() {
        Room selected = roomTable.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showAlert("Select a room to delete.");
            return;
        }

        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS)) {
            String sql = "DELETE FROM rooms WHERE room_number = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, selected.getNumber());
            stmt.executeUpdate();
            showAlert("Room deleted.");
            loadRoomsFromDB();
        } catch (SQLException e) {
            showAlert("Error deleting room: " + e.getMessage());
        }
    }

    private int getRoomTypeId(Connection conn, String name) throws SQLException {
        String sql = "SELECT id FROM room_types WHERE name = ?";
        PreparedStatement stmt = conn.prepareStatement(sql);
        stmt.setString(1, name);
        ResultSet rs = stmt.executeQuery();
        if (rs.next()) {
            return rs.getInt("id");
        } else {
            throw new SQLException("Room type not found.");
        }
    }

    private void clearForm() {
        roomNumberField.clear();
        roomTypeCombo.getSelectionModel().clearSelection();
        availableCheckBox.setSelected(false);
    }

    private void showAlert(String msg) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Rooms");
        alert.setHeaderText(null);
        alert.setContentText(msg);
        alert.showAndWait();
    }
}
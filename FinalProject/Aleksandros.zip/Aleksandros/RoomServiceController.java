package inncontrol;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

import java.sql.*;

public class RoomServiceController {

    @FXML private TableView<RoomService> tableRoomService;
    @FXML private TableColumn<RoomService, String> colRoom;
    @FXML private TableColumn<RoomService, String> colItem;
    @FXML private TableColumn<RoomService, String> colStatus;
    @FXML private TableColumn<RoomService, String> colTimestamp;

    @FXML private TextField roomField;
    @FXML private TextField requestField;

    private final String DB_URL = "jdbc:mysql://localhost:3306/inncontrol";
    private final String DB_USER = "root";
    private final String DB_PASS = "";

    private ObservableList<RoomService> services = FXCollections.observableArrayList();

    @FXML
    public void initialize() {
        colRoom.setCellValueFactory(data -> new javafx.beans.property.SimpleStringProperty(data.getValue().getRoomNumber()));
        colItem.setCellValueFactory(data -> new javafx.beans.property.SimpleStringProperty(data.getValue().getRequest()));
        colStatus.setCellValueFactory(data -> new javafx.beans.property.SimpleStringProperty(data.getValue().getStatus()));
        colTimestamp.setCellValueFactory(data -> new javafx.beans.property.SimpleStringProperty(data.getValue().getTimestamp()));
        loadData();
    }

    private Connection connect() throws SQLException {
        return DriverManager.getConnection(DB_URL, DB_USER, DB_PASS);
    }

    private void loadData() {
        services.clear();
        try (Connection conn = connect()) {
            String query = "SELECT * FROM room_service ORDER BY timestamp DESC";
            PreparedStatement stmt = conn.prepareStatement(query);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                services.add(new RoomService(
                        rs.getInt("id"),
                        rs.getString("room_number"),
                        rs.getString("request"),
                        rs.getString("status"),
                        rs.getString("timestamp")
                ));
            }
            tableRoomService.setItems(services);
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert("Error loading data: " + e.getMessage());
        }
    }

    public void handleAdd() {
        String room = roomField.getText().trim();
        String request = requestField.getText().trim();
        if (room.isEmpty() || request.isEmpty()) {
            showAlert("Please fill in all fields.");
            return;
        }

        try (Connection conn = connect()) {
            String insert = "INSERT INTO room_service (room_number, request, status) VALUES (?, ?, 'Pending')";
            PreparedStatement stmt = conn.prepareStatement(insert);
            stmt.setString(1, room);
            stmt.setString(2, request);
            stmt.executeUpdate();
            showAlert("Request added!");
            roomField.clear();
            requestField.clear();
            loadData();
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert("Error adding request.");
        }
    }

    public void handleDeliver() {
        RoomService selected = tableRoomService.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showAlert("Select a row to mark as delivered.");
            return;
        }

        try (Connection conn = connect()) {
            String update = "UPDATE room_service SET status='Delivered' WHERE id=?";
            PreparedStatement stmt = conn.prepareStatement(update);
            stmt.setInt(1, selected.getId());
            stmt.executeUpdate();
            showAlert("Marked as delivered!");
            loadData();
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert("Error updating status.");
        }
    }

    public void handleDelete() {
        RoomService selected = tableRoomService.getSelectionModel().getSelectedItem();
        if (selected == null) {
            showAlert("Select a row to delete.");
            return;
        }

        try (Connection conn = connect()) {
            String delete = "DELETE FROM room_service WHERE id=?";
            PreparedStatement stmt = conn.prepareStatement(delete);
            stmt.setInt(1, selected.getId());
            stmt.executeUpdate();
            showAlert("Deleted successfully!");
            loadData();
        } catch (SQLException e) {
            e.printStackTrace();
            showAlert("Error deleting request.");
        }
    }

    private void showAlert(String msg) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Room Service");
        alert.setHeaderText(null);
        alert.setContentText(msg);
        alert.showAndWait();
    }
}